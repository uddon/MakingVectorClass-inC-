#pragma once
#define DEFAULT_CAPACITY 30
class MyIntVector {
private:
	int* data;
	size_t capacity;
	size_t size;

public:                                                                            // Members to be Implemented
	// ***** CONSTRUCTORS
	MyIntVector(size_t _capacity = DEFAULT_CAPACITY) :capacity(_capacity), size(0) // Default constructor
	{
		data = new int[capacity];
	}
	MyIntVector(const MyIntVector& v);                                             // Copy constructor for deep copy
	~MyIntVector()                                                                 // Destructor
	{ 
		delete[] data; 
	};
	// ***** OPERATORS
	MyIntVector& operator=(const MyIntVector& v);                                  // Assignment operation (=) for deep copy
	void operator+=(const MyIntVector& v);                                         // Operator : +=
	int operator[](int x);                                                         // Operator : []
	MyIntVector operator+(const MyIntVector& v);                                   // (Binary) operator : +
	MyIntVector operator-(const MyIntVector& v);                                   // (Binary) operator : -
	MyIntVector operator*(const MyIntVector& v);                                   // (Binary) operator : *
	MyIntVector operator-();                                                       // (Unary) operator : -
	bool operator==(const MyIntVector& v);                                         // (Binary) operator : ==
	MyIntVector& operator()(int x);                                                // (Unary) operator : ()  <- int x
	// ***** FUNCTIONS
	void pop_back();                                                               // void pop_back();
	void push_back(int x);                                                         // void push_back(int x);
	size_t Capacity() const { return this->capacity; }                             // size_t capacity() const;
	size_t Size() const { return this->size; }                                     // size_t size() const;
	void reserve(size_t n);                                                        // void reserve(size_t n);
	bool IsEmpty() const;                                                          // bool is_empty() const;
	void clear();                                                                  // void clear();
	// Let's Define New Functions for Printing Data(Elements) in MyIntVector
	void printElem() const;
};