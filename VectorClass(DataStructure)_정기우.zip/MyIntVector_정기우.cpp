#include "MyIntVector.h"
#include <cassert>
#include <cstdlib>
#include <iostream>
using namespace std;

// �ѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤ�
// ***** CONSTRUCTORS
// �ѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤ�
// Copy constructor for deep copy
MyIntVector::MyIntVector(const MyIntVector& v)
{
	// Precondition  : const MyIntVector& object
	// Postcondition : deep copy
	data = new int[v.capacity];
	copy(v.data, v.data + v.size, data);
	this->capacity = v.capacity;
	this->size = v.size;
}
// �ѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤ�

// �ѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤ�
// ***** OPERATORS
// �ѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤ�
// Assignment operation (=) for deep copy
MyIntVector& MyIntVector::operator=(const MyIntVector& v)
{
	// Precondition  : const MyDoubleVector& object
	// Postcondition : deep copy, Bring Memner (for copy) -> Reset
	if (this == &v) return *this; // Return if LHS and RHS are same 
	if (capacity != v.capacity)
	{
        // Allocate new memory space if LHS MyIntVector
		// has different capacity with RHS MyIntVector
		delete[] data;
		data = new int[v.capacity];
		capacity = v.capacity;
	}
	size = v.size;
	copy(v.data, v.data + Size(), data);
	return *this;
}
// Operator : +=
void MyIntVector::operator+=(const MyIntVector& v)
{
	// Precondition  : const MyDoubleVector& object
	// Postcondition : LHS <- LHS + RHS
	if (v.IsEmpty())
		return; // Return if v is empty vector
	while (this->Size() + v.Size() > this->capacity)
		this->reserve(this->Capacity() * 2); // Reserve if need more space
	copy(v.data, v.data + v.Size(), this->data + this->Size());
	size += v.size;
}
// Operator : []
int MyIntVector::operator[](int x)
{
	// Precondition  : Positive Integer, index < used
	// Postcondition : Must return to Reference Form
	//                 Unless, Precondition -> Program Break
	if (x < 0)
	{
		// Throw an error when x is a negative integer.
		cout << "Cannot use negative value for [] operator." << endl;
		exit(-1);
	}
	if (x >= this->Size())
	{
		// Throw an error when x is too big.
		cout << "Out of range during usage of [] operator." << endl;
		exit(-1);
	}
	return data[x];
}
// (Binary) operator : +
MyIntVector MyIntVector::operator+(const MyIntVector& v)
{
	// Precondition  : Same Size const MyDoubleVector& object
	// Postcondition : Add Former Integer and Later One
	//                 Both Integer must be in Same Location
	if (this->Size() != v.Size())
	{
		// Throw an error when two vectors have different size
		cout << "You can't use operator +,-,* with operands having different size value" << endl;
		exit(-1);
	}
	MyIntVector tmp(*this);
	for (unsigned int i = 0; i < tmp.Size(); i++)
		tmp.data[i] += v.data[i];
	return tmp;
}
// (Binary) operator : -
MyIntVector MyIntVector::operator-(const MyIntVector& v)
{
	// Precondition  : Same Size const MyDoubleVector& object
	// Postcondition : Subtract Later Integer from Former One
	//                 Both Integer must be in Same Location
	if (this->Size() != v.Size())
	{
		// Throw an error when two vectors have different size
		cout << "You can't use operator +,-,* with operands having different size value" << endl;
		exit(-1);
	}
	MyIntVector tmp(*this);
	for (unsigned int i = 0; i < tmp.Size(); i++)
		tmp.data[i] -= v.data[i];
	return tmp;
}
// (Binary) operator : *
MyIntVector MyIntVector::operator*(const MyIntVector& v)
{
	// Precondition  : Same Size const MyDoubleVector& object
	// Postcondition : Scala Product Former Integer and Later One
	//                 Both Integer must be in Same Location
	if (this->Size() != v.Size())
	{ // Throw an error when two vectors have different size
		cout << "You can't use operator +,-,* with operands having different size value" << endl;
		exit(-1);
	}
	MyIntVector tmp(*this);
	for (unsigned int i = 0; i < tmp.Size(); i++)
		tmp.data[i] *= v.data[i];
	return tmp;
}
// (Unary) operator : -
MyIntVector MyIntVector::operator-()
{
	// Precondition  : Same Size const MyDoubleVector& object
	// Postcondition : Dot Product "-1" All Members
	if (this->IsEmpty()) 
		return *this; // Return if empty
	MyIntVector tmp(*this);
	for (unsigned int i = 0; i < tmp.Size(); i++)
		tmp.data[i] *= -1;
	return tmp;
}
// (Binary) operator : ==
bool MyIntVector::operator==(const MyIntVector& v)
{
	// Precondition  : const MyDoubleVector& object
	// Postcondition : If, Objects' Size and Element Both Same -> True
	//                 Unless (Not Same),                      -> False
	if (this->Size() != v.Size()) return false;
	else {
		for (unsigned int i = 0; i < this->Size(); i++)
			if (this->data[i] != v.data[i])
				return false;
		return true;
	}
}
// (Unary) operator : ()  <- int x
MyIntVector& MyIntVector::operator()(int x)
{
	// Precondition  : Integer
	// Postcondition : Change All Member in LIst(used) to What I got
	for (unsigned int i = 0; i < this->Size(); i++) this->data[i] = x;
	return *this;
}
// �ѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤ�

// �ѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤ�
// ***** CONSTRUCTORS
// �ѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤ�
// void pop_back();
void MyIntVector::pop_back()
{
	// Precondition  : -  
	// Postcondition : Remove Element which is located in the Last List(used)
	//                 And then, Decrease List's Size "-1"
	// return data[--used];
	if (this->IsEmpty()) return; // Return if empty
	this->size--;
}
// void push_back(int x); <- int entry
void MyIntVector::push_back(int x)
{
	// Precondition  : Integer
	// Postcondition : Add Element into the space, Backside of the Last Element
	if (this->Size() == this->Capacity()) this->reserve(2 * Capacity()); // Reserve if full
	data[this->size] = x;
	this->size++;
}
// �ѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤ�
// size_t capacity() const { return cap; }
// �ѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤ�
// size_t size() const { return used; }
// �ѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤ�
// void reserve(size_t n);
void MyIntVector::reserve(size_t n)
{
	// Precondition  : Positive Integer
	// Postcondition : Change List Size (Number) what I want
	//                 If, Number == List Size -> No Change
	//                 Adding, Make Larger -> Is Okay
	//                 But, Decreasing, Make Smaller -> Is Not Allowed
	if (n < this->Size()) return; // Return if n is smaller than original size
	int* temp = new int[n];
	copy(data, data + this->Size(), temp);
	delete[] data;
	data = temp;
	this->capacity = n;
}
// bool Is_empty() const;
bool MyIntVector::IsEmpty() const
{
	// Precondition  : -  
	// Postcondition : Check whether List(used) is empty,
	//                 If, List is empty -> Return True;
	//                 Unless,           -> Return False;
	if (Size() == 0)
		return true;
	else
		return false;
}
// void clear();
void MyIntVector::clear()
{
	// Precondition  : -  
	// Postcondition : Reset List's Size and Data Both
	this->size = 0;
}
// �ѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤ�
// ***** CONSTRUCTORS _ Cookies
// Let's Define New Functions for Printing Data(Elements) in MyIntVector
void MyIntVector::printElem() const
{
	for (unsigned int i = 0; i < this->Size(); i++)
		cout << "{" << i << "}= " << this->data[i] << " ";
	cout << endl;
}
// �ѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤѤ�