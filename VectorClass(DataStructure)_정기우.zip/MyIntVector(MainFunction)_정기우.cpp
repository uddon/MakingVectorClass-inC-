#include "MyIntVector.h"
#include <iostream>
#include <string>
#include <vector>
using namespace std;

void printVector(MyIntVector& v, string name)
{
	cout << "<" << name << ">'s Size: " << v.Size() << "\n" << "<" << name << ">'s Capacity: " << v.Capacity() << endl;
}

int main(void)
{
	MyIntVector v1;
	cout << "Let's Start Game, MyIntVector !!!!!" << endl;
	cout << endl;
	cout << "* Let's Create vector1 !" << endl;
	printVector(v1, "vector1");
	cout << "vector1's Elements are ..." << endl;
	v1.printElem();
	for (int i = 0; i < 5; i++)
		v1.push_back(i);
	cout << "*Let's Insert Five Elements into 'vector1'" << endl;
	printVector(v1, "vector1");
	v1.printElem();
	cout << "vector1[0]: " << v1[0] << endl;
	cout << "vector1[1]: " << v1[1] << endl;
	cout << "vector1[2]: " << v1[2] << endl;
	cout << "vector1[3]: " << v1[3] << endl;
	cout << "vector1[4]: " << v1[4] << endl;
	cout << endl;
	MyIntVector v2(v1);
	cout << "* Let's Create vector2 !" << endl;
	printVector(v2, "vector2");
	cout << "vector2's Elements are ..." << endl;
	v2.printElem();
	// Operator : +=
	v2 += v1;
	cout << endl;
	cout << "*** Let's Check Operator +=" << endl;
	cout << "vector2 += vector1" << endl;
	printVector(v2, "vector2");
	v2.printElem();
	// (Binary) Operator : ==
	cout << endl;
	MyIntVector v3;
	v3 = v2 = v1;
	cout << "* Let's Create vector3 !" << endl;
	cout << "vector3 = vector2 = vector1" << endl;
	printVector(v3, "vector3");
	v3.printElem();
	cout << endl;
	cout << "*** Let's Check (Binary) Operator ==" << endl;
	cout << "Are vector1 & vector3 Same? " << endl;
	if (v3 == v1)
		cout << "TRUE" << endl;
	else
		cout << "FALSE" << endl;
	// void push_back(int x);
	cout << endl;
	for (int i = 0; i < 10; i++)
		v3.push_back(0);
	cout << "Insert 10 Elements in 'vector1'" << endl;
	printVector(v3, "vector3");
	cout << endl;
	cout << "*** Let's Check void push_back (int x)" << endl;
	v3.printElem();
	// (Unary) operator : ()  <- int x
	cout << endl;
	v3(7);
	cout << "*** Let's Check (Unary) operator ()" << endl;
	cout << "All Elements in vector3 Changed Into Integer '7'" << endl;
	MyIntVector v4(v3);
	v4(1);
	cout << endl;
	cout << "* Let's Create vector4 !" << endl;
	cout << "All Elements in vector4 Changed Into Integer '1'" << endl;
	// (Binary) operator : +
	cout << endl;
	v3 = v3 + v4; // v3 <- integer, (v3+v4) = (7+1) = 8
	cout << "*** Let's Check (Binary) operator +" << endl;
	cout << "vector3 = vector3 + vector4" << endl;
	printVector(v3, "vector3");
	v3.printElem();
	// (Binary) operator : -
	cout << endl;
	v3 = v3 - v4; // v3 <- Integer, (v3-v4) = (7-1) = 6
	cout << "*** Let's Check (Binary) operator -" << endl;
	cout << "vector3 = vector3 - vector4" << endl;
	printVector(v3, "vector3");
	v3.printElem();
	// (Binary) operator : *
	cout << endl;
	v3 = v3 * v4; // v3 <- Integer, (v3*v4) = (7*1) = 7
	cout << "*** Let's Check (Binary) operator *" << endl;
	cout << "vector3 = vector3 * vector4" << endl;
	printVector(v3, "vector3");
	v3.printElem();
	// (Unary) operator : -
	cout << endl;
	v3 = -v3; // v3 <- Integer, (-1)*(v3) = - (v3)
	cout << "*** Let's Check (Unary) operator -" << endl;
	cout << "vector3 = - vector3" << endl;
	printVector(v3, "vector3");
	v3.printElem();
	// void pop_back();
	cout << endl;
	v3.pop_back(); // pop_back() == pop_back(1)
	               // v3 (vector3) 's Size Decrease Integer "1"
	cout << "*** Let's Check void pop_back ()" << endl;
	cout << "Let's Decrease <vector3>'s Size the Number 'ONE'" << endl;
	printVector(v3, "vector3");
	v3.printElem();
	// void reserve(size_t n);
	cout << endl;
	v3.reserve(15); // v3 (vector3) 's Capacity Change Into Integer "15"
	cout << "*** Let's Check void reserve (size_t n)" << endl;
	cout << "Let's Reserve <vector3>'s Capacity Size Into Fifteen '15'" << endl;
	printVector(v3, "vector3");
	v3.printElem();
	// void clear();
	cout << endl;
	v3.clear(); // v3 (vector3) 's Size Turn Into Integer "0"
	cout << "*** Let's Check void clear ()" << endl;
	cout << "Let's Erase <vector3>'s Data, Wholly" << endl;
	printVector(v3, "vector3");
	v3.printElem();
	cout << "Finally, " << endl;
	cout << "Is vector3 wholly Erased, Empty?" << endl;
	if (v3.IsEmpty())
		cout << "TRUE" << endl;
	else
		cout << "FALSE" << endl;
	return 0;
}